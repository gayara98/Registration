package com.example.registration;

import android.os.Bundle;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class SummaryActivity extends AppCompatActivity {

    private TextView textSummary;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_summary);

        textSummary = findViewById(R.id.textSummary);

        // Retrieve the passed details from SecondActivity
        Bundle extras = getIntent().getExtras();
        if (extras != null) {
            String name = extras.getString("name");
            String id = extras.getString("id");
            String address = extras.getString("address");
            String email = extras.getString("email");
            String phone = extras.getString("phone");

            // Display the details in the textSummary TextView
            String summary = "Name: " + name + "\n" +
                    "ID: " + id + "\n" +
                    "Address: " + address + "\n" +
                    "Email: " + email + "\n" +
                    "Phone: " + phone;
            textSummary.setText(summary);
        }


    }
}

