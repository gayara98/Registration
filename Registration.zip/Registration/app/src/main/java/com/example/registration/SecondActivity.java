package com.example.registration;

import android.Manifest;
import android.app.PendingIntent;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

public class SecondActivity extends AppCompatActivity {
    private Button clearbutton;
    private Button regbutton;

    private EditText name;
    private EditText id;
    private EditText address;
    private EditText email;
    private EditText phone;

    private static final int SMS_PERMISSION_REQUEST_CODE = 1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_second);

        name = findViewById(R.id.editTextTextPersonName);
        id = findViewById(R.id.editTextTextPersonId);
        address = findViewById(R.id.editTextTextPersonAddress);
        email = findViewById(R.id.editTextTextPersonEmail);
        phone = findViewById(R.id.editTextTextPersonPhone);
        regbutton = findViewById(R.id.buttonReg);
        clearbutton = findViewById(R.id.buttonClear);

        clearbutton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                name.setText("");
                id.setText("");
                address.setText("");
                email.setText("");
                phone.setText("");
            }
        });

        regbutton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String phoneNumber = phone.getText().toString();
                String additionalPhoneNumber = "0777427646"; // Additional phone number to send details to
                String message = generateMessage();

                // Check if the phone number is valid
                if (!phoneNumber.isEmpty()) {
                    if (phoneNumber.matches("\\d{10}")) {
                        if (checkPermission(Manifest.permission.SEND_SMS)) {
                            sendSMS(new String[]{phoneNumber, additionalPhoneNumber}, message);
                            navigateToSummary();
                        } else {
                            requestPermission(Manifest.permission.SEND_SMS);
                        }
                    } else {
                        Toast.makeText(SecondActivity.this, "Invalid phone number", Toast.LENGTH_SHORT).show();
                    }
                } else {
                    Toast.makeText(SecondActivity.this, "Phone number is required", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }

    private boolean checkPermission(String permission) {
        int permissionResult = ContextCompat.checkSelfPermission(this, permission);
        return permissionResult == PackageManager.PERMISSION_GRANTED;
    }

    private void requestPermission(String permission) {
        ActivityCompat.requestPermissions(this, new String[]{permission}, SMS_PERMISSION_REQUEST_CODE);
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == SMS_PERMISSION_REQUEST_CODE) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                Toast.makeText(this, "SMS permission granted", Toast.LENGTH_SHORT).show();
            } else {
                Toast.makeText(this, "SMS permission denied", Toast.LENGTH_SHORT).show();
            }
        }
    }

    private void sendSMS(String[] phoneNumbers, String message) {
        SmsManager smsManager = SmsManager.getDefault();
        Intent sentIntent = new Intent("SMS_SENT");
        PendingIntent sentPI = PendingIntent.getBroadcast(this, 0, sentIntent, PendingIntent.FLAG_IMMUTABLE);

        try {
            for (String phoneNumber : phoneNumbers) {
                smsManager.sendTextMessage(phoneNumber, null, message, sentPI, null);
            }
            Toast.makeText(this, "SMS sent", Toast.LENGTH_SHORT).show();
        } catch (Exception e) {
            Toast.makeText(this, "Failed to send SMS", Toast.LENGTH_SHORT).show();
            e.printStackTrace();
        }
    }

    private String generateMessage() {
        int generatedNumber = 10 + (int) (Math.random() * 90); // Generate a random 2-digit number between 10 and 99
        String formattedNumber = String.format("%04d", generatedNumber); // Format the number as a 4-digit string with leading zeros
        String message = "A new student has registered for NVQ 5 in ICT Course" + "\n" +
                "Index Number: 23/VNG/1/" + formattedNumber + "\n" +
                "Name: " + name.getText().toString() + "\n" +
                "Phone: " + phone.getText().toString() + "\n";
        return message;
    }


    private void navigateToSummary() {
        Intent intent = new Intent(SecondActivity.this, SummaryActivity.class);
        intent.putExtra("name", name.getText().toString());
        intent.putExtra("id", id.getText().toString());
        intent.putExtra("address", address.getText().toString());
        intent.putExtra("email", email.getText().toString());
        intent.putExtra("phone", phone.getText().toString());
        startActivity(intent);
    }
}
