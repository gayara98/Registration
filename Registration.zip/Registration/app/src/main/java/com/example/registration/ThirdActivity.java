package com.example.registration;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;

public class ThirdActivity extends AppCompatActivity {
    private ImageButton imgbtn;

    private Button btnsem1;

    private Button btnsem2;

    private Button btnsem3;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_third);

        imgbtn = findViewById(R.id.imageButton);
        imgbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(ThirdActivity.this, AboutActivity.class);
                startActivity(intent);
            }
        });

        btnsem1 = findViewById(R.id.buttonsem1);
        btnsem1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(ThirdActivity.this, Sem1Activity.class);
                startActivity(intent);
            }
        });

        btnsem2 = findViewById(R.id.buttonsem2);
        btnsem2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(ThirdActivity.this, Sem2Activity.class);
                startActivity(intent);
            }
        });
        btnsem3 = findViewById(R.id.buttonsem3);
        btnsem3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(ThirdActivity.this, Sem3Activity.class);
                startActivity(intent);
            }
        });

    }
}